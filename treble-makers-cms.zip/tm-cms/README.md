# The Treble Makers — CMS

A lightweight content management layer for the Treble Makers site, built on Netlify Functions + Blobs. Jessica logs in at `/admin`, edits sections in a form UI, and changes go live to the next visitor. No redeploys, no git commits.

## What it does

- **Public site** at `/` — renders sections dynamically from JSON
- **Admin** at `/admin` — password-protected editor
- **Editing** — text, images (URL paste or upload), all list items (testimonials, services, timeline stages), plus adding, removing, reordering, and hiding sections
- **Section library** — 12 templates: hero, trust bar, timeline, services grid, feature block, rate list, testimonials, CTA strip, text block, image+text, gallery, video embed, announcement banner
- **Site settings** — nav and footer editable from a separate panel
- **History** — 30 days of automatic snapshots on every save; one-click restore
- **Save = live** — every edit persists immediately. Public site caches for 60 seconds so worst-case delay to a new visitor is one minute.

## Architecture

```
Public site (static shell)
      │
      ▼
GET /api/content/home ─────► Netlify Function ─────► Netlify Blobs (JSON)
                                                          │
Admin UI                                                  │
   │                                                      │
   ▼                                                      │
POST /api/login (bcrypt + JWT)                            │
PUT  /api/content/home  ──────────────────────────────────┘
POST /api/upload  ─────► Netlify Blobs (images)
```

One JSON blob per page. History is embedded in the same blob (last 30 days, max 100 entries). Images stored in a separate Blobs store, served via a function with a 1-year immutable cache.

## Setup

**Requirements:** Node.js 18+, a Netlify account, this repo pushed to GitHub.

### 1. Install dependencies

```bash
npm install
```

### 2. Generate an admin password hash

```bash
npm run hash-password
```

Enter the password you'll give Jessica. Copy the printed hash — you'll paste it into Netlify in a moment.

### 3. Generate a JWT secret

Any random 32+ character string. On macOS/Linux:

```bash
openssl rand -base64 48
```

### 4. Deploy to Netlify

- Push this repo to GitHub
- In Netlify: **Add new site → Import from Git**, pick the repo
- Build settings should auto-detect from `netlify.toml`. Publish directory: `public`. Functions directory: `netlify/functions`.
- Deploy the site once so Netlify provisions the environment.

### 5. Enable Netlify Blobs

- In your site dashboard: **Integrations → Netlify Blobs → Enable** (or it may already be on for new sites — check under Site configuration).
- Free tier is fine.

### 6. Set environment variables

In Netlify: **Site configuration → Environment variables → Add**

| Name | Value |
|---|---|
| `ADMIN_PASSWORD_HASH` | The hash from step 2 |
| `JWT_SECRET` | The random string from step 3 |

Redeploy after adding (Netlify → Deploys → Trigger deploy → Deploy site).

### 7. Seed the initial content

Two options.

**Option A — automated (recommended):**

```bash
SITE_URL=https://your-site.netlify.app ADMIN_PASSWORD=the_password_you_chose \
  node scripts/seed-content.mjs
```

**Option B — manual:**

Visit `/admin`, log in, then use the "Add section" button to build the page from scratch. The site will show an empty state until at least one section exists.

### 8. Point Jessica at `/admin`

Share the URL and the password. She's in.

## Day-to-day usage

- **Editing:** Click a section in the sidebar → edit fields → auto-saves after ~1 sec of no typing.
- **Adding a section:** "+ Add section" → pick a template.
- **Reordering:** Drag the `⋮⋮` handle on section cards.
- **Hiding without deleting:** Section editor → "Hide". Hidden sections don't render on the public site but stay in the sidebar with a strikethrough.
- **Undo a mistake:** History panel → find the version → Restore.
- **Uploading images:** In any image field, click "Upload" and pick a file (max 5MB, JPG/PNG/WebP/GIF), or paste an image URL directly.

## Costs

Entirely on Netlify's free tier for the traffic scale of this site:

- Functions: 125K requests/month free
- Blobs: 100GB storage, 100GB bandwidth free
- Bandwidth: 100GB/month free
- One custom domain included

Expected monthly cost: **$0**.

## What this is not

- **Not a WYSIWYG.** Fields are form-based, not "click in the page and type." Jessica sees the change by opening the public site in another tab.
- **Not modular layout.** She picks from a fixed library of section templates. Adding a new template = a dev ticket to write its schema, form, and renderer.
- **Not multi-user.** One shared password. Fine for a solo operator; would need real auth for a team.
- **Not draft/publish.** Every save is live. History covers accidents.

## Files at a glance

```
public/
  index.html              # public site shell (mostly empty, JS fills it)
  admin.html              # admin shell
  styles/
    public.css            # public site styling
    admin.css             # admin UI styling
  scripts/
    schemas.js            # section template definitions (shared)
    public.js             # public site renderer
    admin.js              # admin SPA (login, edit, save, history)

netlify/functions/
  login.mjs               # POST /api/login  — password → JWT cookie
  logout.mjs              # POST /api/logout
  content.mjs             # GET /api/content/:id (public) & PUT (authed)
  upload.mjs              # POST /api/upload — image upload to Blobs
  image.mjs               # GET /api/image/:key — serves uploaded images
  history.mjs             # GET /api/history/:id — authed history list
  restore.mjs             # POST /api/restore — restore a snapshot
  _shared/
    auth.mjs              # JWT + password helpers
    store.mjs             # Blobs wrapper + 30-day pruning

scripts/
  hash-password.mjs       # local CLI: hash a password
  seed-content.mjs        # bootstrap the home page JSON

netlify.toml              # Netlify config + API redirects
package.json
```

## Adding a new section template later

1. Add its schema to `public/scripts/schemas.js` in the `TEMPLATES` object.
2. Add its renderer to `public/scripts/public.js` in the `RENDERERS` object.
3. Add supporting CSS in `public/styles/public.css`.
4. Commit and push. The admin's "Add section" modal picks it up automatically.

## Troubleshooting

- **"Session expired" every few minutes** — check that `JWT_SECRET` is set and stable across function cold starts.
- **Uploads fail** — verify Netlify Blobs is enabled. Check function logs in the Netlify dashboard.
- **Public site is blank** — no content has been seeded yet. Run the seed script or add a section from `/admin`.
- **Edits don't appear on public site** — the browser caches for 60 sec. Hard-refresh (Cmd+Shift+R) or wait a minute.

## Security notes

- Admin is protected by a single shared password + HTTP-only session cookie (7-day expiry).
- Password is bcrypt-hashed at rest (env var).
- All admin API calls require valid JWT.
- No 2FA. Rotate the password if it's ever shared with someone who leaves.
- Image uploads are validated by content-type and size-capped at 5MB.
- No XSS: renderer escapes all text; the only rich-text convention is `*word*` → italics in titles.
