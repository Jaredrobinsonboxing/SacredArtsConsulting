import { requireAuth } from './_shared/auth.mjs';
import { getPage } from './_shared/store.mjs';

export default async (request) => {
  const unauth = requireAuth(request);
  if (unauth) return unauth;

  const url = new URL(request.url);
  const pageId = url.searchParams.get('pageId') || 'home';
  const page = await getPage(pageId);
  if (!page) return json({ history: [] });

  return json({
    pageId,
    history: (page.history || []).map(h => ({
      timestamp: h.timestamp,
      sectionCount: h.sections?.length || 0
    }))
  });
};

function json(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'content-type': 'application/json' }
  });
}
