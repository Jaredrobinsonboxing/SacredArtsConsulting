import { getStore } from '@netlify/blobs';

const HISTORY_MAX_DAYS = 30;
const HISTORY_MAX_ENTRIES = 100; // hard ceiling so a burst can't bloat storage

function contentStore() {
  return getStore('content');
}

function imageStore() {
  return getStore('images');
}

export async function getPage(pageId) {
  const store = contentStore();
  const data = await store.get(pageId, { type: 'json' });
  if (!data) return null;
  return data;
}

export async function savePage(pageId, newSections, opts = {}) {
  const store = contentStore();
  const existing = await store.get(pageId, { type: 'json' });
  const now = new Date().toISOString();

  // Snapshot the previous "current" into history before overwriting
  const history = existing?.history ?? [];
  if (existing?.current) {
    history.unshift({
      timestamp: existing.updatedAt || now,
      sections: existing.current.sections
    });
  }

  const pruned = pruneHistory(history);

  const doc = {
    pageId,
    updatedAt: now,
    current: {
      sections: newSections,
      nav: opts.nav ?? existing?.current?.nav,
      footer: opts.footer ?? existing?.current?.footer,
      meta: opts.meta ?? existing?.current?.meta
    },
    history: pruned
  };

  await store.setJSON(pageId, doc);
  return doc;
}

export async function saveFullPage(pageId, current) {
  // Used when nav/footer/sections all change together (from admin site-settings)
  const store = contentStore();
  const existing = await store.get(pageId, { type: 'json' });
  const now = new Date().toISOString();

  const history = existing?.history ?? [];
  if (existing?.current) {
    history.unshift({
      timestamp: existing.updatedAt || now,
      sections: existing.current.sections,
      nav: existing.current.nav,
      footer: existing.current.footer
    });
  }

  const doc = {
    pageId,
    updatedAt: now,
    current,
    history: pruneHistory(history)
  };

  await store.setJSON(pageId, doc);
  return doc;
}

export function pruneHistory(history) {
  if (!Array.isArray(history)) return [];
  const cutoff = Date.now() - HISTORY_MAX_DAYS * 24 * 60 * 60 * 1000;
  const filtered = history.filter(entry => {
    const t = Date.parse(entry.timestamp);
    return Number.isFinite(t) && t >= cutoff;
  });
  return filtered.slice(0, HISTORY_MAX_ENTRIES);
}

export async function restoreVersion(pageId, timestamp) {
  const store = contentStore();
  const existing = await store.get(pageId, { type: 'json' });
  if (!existing) throw new Error('page not found');
  const snapshot = existing.history.find(h => h.timestamp === timestamp);
  if (!snapshot) throw new Error('history entry not found');

  // Snapshot current before restoring
  const now = new Date().toISOString();
  const history = [
    {
      timestamp: existing.updatedAt || now,
      sections: existing.current.sections,
      nav: existing.current.nav,
      footer: existing.current.footer
    },
    ...existing.history
  ];

  const doc = {
    pageId,
    updatedAt: now,
    current: {
      sections: snapshot.sections,
      nav: snapshot.nav ?? existing.current.nav,
      footer: snapshot.footer ?? existing.current.footer,
      meta: existing.current.meta
    },
    history: pruneHistory(history)
  };

  await store.setJSON(pageId, doc);
  return doc;
}

// --- Images ---

export async function putImage(key, buffer, contentType) {
  const store = imageStore();
  await store.set(key, buffer, {
    metadata: { contentType, uploadedAt: new Date().toISOString() }
  });
}

export async function getImage(key) {
  const store = imageStore();
  const result = await store.getWithMetadata(key, { type: 'arrayBuffer' });
  if (!result) return null;
  return {
    buffer: result.data,
    contentType: result.metadata?.contentType || 'application/octet-stream'
  };
}
