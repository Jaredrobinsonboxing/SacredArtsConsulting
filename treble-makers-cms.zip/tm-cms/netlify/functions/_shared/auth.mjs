import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

const COOKIE_NAME = 'tm_session';
const SESSION_DAYS = 7;

function getSecret() {
  const s = process.env.JWT_SECRET;
  if (!s || s.length < 32) {
    throw new Error('JWT_SECRET env var missing or too short (need 32+ chars)');
  }
  return s;
}

export async function verifyPassword(password) {
  const hash = process.env.ADMIN_PASSWORD_HASH;
  if (!hash) throw new Error('ADMIN_PASSWORD_HASH env var missing');
  return bcrypt.compare(password, hash);
}

export function issueSessionCookie() {
  const token = jwt.sign(
    { role: 'admin', iat: Math.floor(Date.now() / 1000) },
    getSecret(),
    { expiresIn: `${SESSION_DAYS}d` }
  );
  const maxAge = SESSION_DAYS * 24 * 60 * 60;
  return `${COOKIE_NAME}=${token}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${maxAge}`;
}

export function clearSessionCookie() {
  return `${COOKIE_NAME}=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0`;
}

function parseCookies(header) {
  const out = {};
  if (!header) return out;
  header.split(';').forEach(part => {
    const idx = part.indexOf('=');
    if (idx > -1) {
      const k = part.slice(0, idx).trim();
      const v = part.slice(idx + 1).trim();
      out[k] = v;
    }
  });
  return out;
}

export function isAuthenticated(request) {
  try {
    const cookies = parseCookies(request.headers.get('cookie'));
    const token = cookies[COOKIE_NAME];
    if (!token) return false;
    jwt.verify(token, getSecret());
    return true;
  } catch {
    return false;
  }
}

export function requireAuth(request) {
  if (!isAuthenticated(request)) {
    return new Response(JSON.stringify({ error: 'Unauthorized' }), {
      status: 401,
      headers: { 'content-type': 'application/json' }
    });
  }
  return null;
}
