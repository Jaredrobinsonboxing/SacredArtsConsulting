import { requireAuth } from './_shared/auth.mjs';
import { restoreVersion } from './_shared/store.mjs';

export default async (request) => {
  if (request.method !== 'POST') {
    return new Response('Method Not Allowed', { status: 405 });
  }
  const unauth = requireAuth(request);
  if (unauth) return unauth;

  try {
    const { pageId, timestamp } = await request.json();
    if (!pageId || !timestamp) {
      return json({ error: 'pageId and timestamp required' }, 400);
    }
    const doc = await restoreVersion(pageId, timestamp);
    return json({ ok: true, updatedAt: doc.updatedAt });
  } catch (err) {
    console.error('restore error', err);
    return json({ error: err.message || 'Restore failed' }, 500);
  }
};

function json(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'content-type': 'application/json' }
  });
}
