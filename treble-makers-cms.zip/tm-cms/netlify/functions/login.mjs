import { verifyPassword, issueSessionCookie } from './_shared/auth.mjs';

export default async (request) => {
  if (request.method !== 'POST') {
    return new Response('Method Not Allowed', { status: 405 });
  }

  try {
    const { password } = await request.json();
    if (!password || typeof password !== 'string') {
      return json({ error: 'Password required' }, 400);
    }

    const ok = await verifyPassword(password);
    if (!ok) {
      // Small delay to slow brute force
      await new Promise(r => setTimeout(r, 500));
      return json({ error: 'Invalid password' }, 401);
    }

    return new Response(JSON.stringify({ ok: true }), {
      status: 200,
      headers: {
        'content-type': 'application/json',
        'set-cookie': issueSessionCookie()
      }
    });
  } catch (err) {
    console.error('login error', err);
    return json({ error: 'Login failed' }, 500);
  }
};

function json(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'content-type': 'application/json' }
  });
}
