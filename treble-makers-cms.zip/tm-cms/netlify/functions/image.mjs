import { getImage } from './_shared/store.mjs';

export default async (request) => {
  const url = new URL(request.url);
  const key = url.searchParams.get('key');
  if (!key) return new Response('Missing key', { status: 400 });

  // Guard against traversal / weird keys
  if (!/^[a-zA-Z0-9._-]+$/.test(key)) {
    return new Response('Bad key', { status: 400 });
  }

  const img = await getImage(key);
  if (!img) return new Response('Not found', { status: 404 });

  return new Response(img.buffer, {
    status: 200,
    headers: {
      'content-type': img.contentType,
      // Filenames include a timestamp + random id, so URLs are effectively immutable
      'cache-control': 'public, max-age=31536000, immutable'
    }
  });
};
