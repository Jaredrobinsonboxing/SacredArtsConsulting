import { requireAuth } from './_shared/auth.mjs';
import { putImage } from './_shared/store.mjs';

const MAX_BYTES = 5 * 1024 * 1024; // 5MB per image
const ALLOWED = new Set(['image/jpeg', 'image/png', 'image/webp', 'image/gif']);

export default async (request) => {
  if (request.method !== 'POST') {
    return new Response('Method Not Allowed', { status: 405 });
  }
  const unauth = requireAuth(request);
  if (unauth) return unauth;

  try {
    const { filename, contentType, data } = await request.json();

    if (!filename || !contentType || !data) {
      return json({ error: 'filename, contentType, and data (base64) required' }, 400);
    }
    if (!ALLOWED.has(contentType)) {
      return json({ error: `Unsupported type: ${contentType}` }, 400);
    }

    // Decode
    const buffer = Buffer.from(data, 'base64');
    if (buffer.length > MAX_BYTES) {
      return json({ error: `Image too large (max ${MAX_BYTES / 1024 / 1024}MB)` }, 400);
    }

    // Generate key
    const ext = contentType.split('/')[1].replace('jpeg', 'jpg');
    const key = `${Date.now()}-${randomId(8)}.${ext}`;

    await putImage(key, buffer, contentType);

    return json({
      ok: true,
      key,
      url: `/api/image/${key}`,
      size: buffer.length,
      filename
    });
  } catch (err) {
    console.error('upload error', err);
    return json({ error: 'Upload failed', detail: err.message }, 500);
  }
};

function json(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'content-type': 'application/json' }
  });
}

function randomId(n) {
  const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
  let out = '';
  for (let i = 0; i < n; i++) out += chars[Math.floor(Math.random() * chars.length)];
  return out;
}
