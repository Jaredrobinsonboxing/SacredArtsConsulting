import { getPage, saveFullPage } from './_shared/store.mjs';
import { requireAuth, isAuthenticated } from './_shared/auth.mjs';

export default async (request) => {
  const url = new URL(request.url);
  const pageId = url.searchParams.get('pageId') || 'home';

  if (request.method === 'GET') {
    const page = await getPage(pageId);
    if (!page) return json({ error: 'Not found' }, 404);

    // Public GET returns current state without history unless authed
    const authed = isAuthenticated(request);
    const payload = {
      pageId: page.pageId,
      updatedAt: page.updatedAt,
      current: page.current,
      ...(authed ? { history: page.history?.map(h => ({ timestamp: h.timestamp })) } : {})
    };
    return new Response(JSON.stringify(payload), {
      status: 200,
      headers: {
        'content-type': 'application/json',
        // Short cache — new visitors after an edit see it within 60s worst case
        'cache-control': 'public, max-age=60, stale-while-revalidate=300'
      }
    });
  }

  if (request.method === 'PUT') {
    const unauth = requireAuth(request);
    if (unauth) return unauth;

    try {
      const body = await request.json();
      const { current } = body;

      if (!current || !Array.isArray(current.sections)) {
        return json({ error: 'Invalid payload: current.sections must be an array' }, 400);
      }

      // Basic sanity checks
      for (const s of current.sections) {
        if (!s.id || !s.type) {
          return json({ error: 'Every section needs id and type' }, 400);
        }
      }

      const doc = await saveFullPage(pageId, current);
      return json({ ok: true, updatedAt: doc.updatedAt });
    } catch (err) {
      console.error('save error', err);
      return json({ error: 'Save failed', detail: err.message }, 500);
    }
  }

  return new Response('Method Not Allowed', { status: 405 });
};

function json(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'content-type': 'application/json' }
  });
}
