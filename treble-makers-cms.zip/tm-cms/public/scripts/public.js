// Public site renderer.
// Fetches page JSON, renders sections from templates, caches for 5 min.

const CACHE_KEY = 'tm_page_home';
const CACHE_TTL_MS = 5 * 60 * 1000;
const PAGE_ID = 'home';

async function loadPage() {
  // Try cache first for instant paint
  const cached = readCache();
  if (cached) {
    render(cached);
    // Revalidate in background
    fetchFresh().then(fresh => {
      if (fresh && fresh.updatedAt !== cached.updatedAt) {
        render(fresh);
        writeCache(fresh);
      }
    });
    return;
  }

  const fresh = await fetchFresh();
  if (fresh) {
    render(fresh);
    writeCache(fresh);
  } else {
    document.getElementById('sections-slot').innerHTML =
      '<div class="site-loading">This site is being set up. Check back soon.</div>';
  }
}

async function fetchFresh() {
  try {
    const res = await fetch(`/api/content/${PAGE_ID}`, { credentials: 'same-origin' });
    if (!res.ok) return null;
    return await res.json();
  } catch (err) {
    console.error('fetch failed', err);
    return null;
  }
}

function readCache() {
  try {
    const raw = localStorage.getItem(CACHE_KEY);
    if (!raw) return null;
    const { data, at } = JSON.parse(raw);
    if (Date.now() - at > CACHE_TTL_MS) return null;
    return data;
  } catch { return null; }
}

function writeCache(data) {
  try {
    localStorage.setItem(CACHE_KEY, JSON.stringify({ data, at: Date.now() }));
  } catch {}
}

// --- Rendering ---

function render(page) {
  const { current } = page;
  if (!current) return;

  renderNav(current.nav);
  renderSections(current.sections || []);
  renderFooter(current.footer);
}

function renderNav(nav) {
  const slot = document.getElementById('nav-slot');
  if (!nav) { slot.innerHTML = ''; return; }
  const links = (nav.links || [])
    .map(l => `<a href="${escapeAttr(l.url)}">${escapeText(l.text)}</a>`)
    .join('');
  slot.innerHTML = `
    <nav class="top">
      <div class="row">
        <a href="#" class="brand">
          <div class="brand-mark">${escapeText((nav.brand || 'T').charAt(0).toLowerCase())}</div>
          <span>${escapeText(nav.brand || '')}</span>
        </a>
        <div class="nav-links">
          ${links}
          ${nav.ctaText ? `<a href="${escapeAttr(nav.ctaUrl || '#')}" class="nav-cta">${escapeText(nav.ctaText)}</a>` : ''}
        </div>
      </div>
    </nav>
  `;
}

function renderSections(sections) {
  renderAnnouncement(sections);
  const slot = document.getElementById('sections-slot');
  const visible = sections
    .filter(s => s.visible !== false)
    .sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
  slot.innerHTML = visible.map(renderSection).filter(Boolean).join('');
}

function renderSection(s) {
  const renderer = RENDERERS[s.type];
  if (!renderer) {
    console.warn('Unknown section type:', s.type);
    return '';
  }
  try {
    return renderer(s.content || {}, s.id);
  } catch (err) {
    console.error('Render error for', s.type, err);
    return '';
  }
}

// --- Section renderers ---
// Each takes a content object and returns HTML.

const RENDERERS = {
  hero(c, id) {
    return `
      <section class="hero" id="${escapeAttr(id)}">
        <div class="container">
          <div class="hero-grid">
            <div>
              ${c.eyebrow ? `<span class="eyebrow">${escapeText(c.eyebrow)}</span>` : ''}
              <h1 class="hero-title">${formatItalics(c.title || '')}</h1>
              ${c.sub ? `<p class="hero-sub">${escapeText(c.sub)}</p>` : ''}
              <div class="hero-actions">
                ${c.ctaPrimaryText ? `<a href="${escapeAttr(c.ctaPrimaryUrl || '#')}" class="btn-primary">${escapeText(c.ctaPrimaryText)} →</a>` : ''}
                ${c.ctaSecondaryText ? `<a href="${escapeAttr(c.ctaSecondaryUrl || '#')}" class="btn-secondary">${escapeText(c.ctaSecondaryText)}</a>` : ''}
              </div>
            </div>
            <div class="hero-visual">
              ${c.photoMain ? `<div class="hero-photo p1"><img src="${escapeAttr(c.photoMain)}" alt=""></div>` : ''}
              ${c.photoSecondary ? `<div class="hero-photo p2"><img src="${escapeAttr(c.photoSecondary)}" alt=""></div>` : ''}
              ${(c.badgeTop || c.badgeBottom) ? `
                <div class="hero-photo p3">
                  <div>
                    ${c.badgeTop ? `<span>${escapeText(c.badgeTop)}</span>` : ''}
                    ${c.badgeBottom ? escapeText(c.badgeBottom) : ''}
                  </div>
                </div>` : ''}
            </div>
          </div>
        </div>
      </section>
    `;
  },

  'trust-bar'(c, id) {
    const items = (c.items || []).map(i => `<div class="trust-item">${escapeText(i.text || '')}</div>`).join('');
    return `<div class="trust" id="${escapeAttr(id)}"><div class="container"><div class="trust-row">${items}</div></div></div>`;
  },

  'text-block'(c, id) {
    return `
      <section id="${escapeAttr(id)}">
        <div class="container">
          ${c.label ? `<span class="section-label">${escapeText(c.label)}</span>` : ''}
          ${c.title ? `<h2 class="section-title">${formatItalics(c.title)}</h2>` : ''}
          ${c.body ? `<p class="section-lede">${escapeText(c.body)}</p>` : ''}
        </div>
      </section>
    `;
  },

  'image-text'(c, id) {
    const reverse = c.imagePosition === 'right' ? 'reverse' : '';
    return `
      <section id="${escapeAttr(id)}">
        <div class="container">
          <div class="image-text-block ${reverse}">
            <div class="it-photo">${c.image ? `<img src="${escapeAttr(c.image)}" alt="">` : ''}</div>
            <div class="it-content">
              ${c.label ? `<span class="section-label">${escapeText(c.label)}</span>` : ''}
              ${c.title ? `<h2 class="section-title">${formatItalics(c.title)}</h2>` : ''}
              ${c.body ? `<p class="section-lede" style="margin-bottom:24px;">${escapeText(c.body)}</p>` : ''}
              ${c.ctaText ? `<a href="${escapeAttr(c.ctaUrl || '#')}" class="btn-primary">${escapeText(c.ctaText)} →</a>` : ''}
            </div>
          </div>
        </div>
      </section>
    `;
  },

  timeline(c, id) {
    const cols = (c.stages || []).length || 6;
    const stages = (c.stages || []).map(s => `
      <div class="stage">
        <div class="stage-age">${escapeText(s.age || '')}</div>
        <div class="stage-label">${escapeText(s.label || '')}</div>
        <div class="stage-desc">${escapeText(s.desc || '')}</div>
      </div>
    `).join('');
    return `
      <section class="stages" id="${escapeAttr(id)}" style="--stage-cols:${cols};">
        <div class="container">
          ${c.label ? `<span class="section-label">${escapeText(c.label)}</span>` : ''}
          ${c.title ? `<h2 class="section-title">${formatItalics(c.title)}</h2>` : ''}
          ${c.lede ? `<p class="section-lede">${escapeText(c.lede)}</p>` : ''}
          <div class="stage-track">${stages}</div>
        </div>
      </section>
    `;
  },

  services(c, id) {
    const cards = (c.cards || []).map(card => `
      <div class="svc-card">
        <div class="svc-img">
          ${card.image ? `<img src="${escapeAttr(card.image)}" alt="">` : ''}
          ${card.tag ? `<div class="svc-tag">${escapeText(card.tag)}</div>` : ''}
        </div>
        <div class="svc-body">
          <h3>${escapeText(card.title || '')}</h3>
          <p>${escapeText(card.desc || '')}</p>
          ${card.priceAmount ? `<div class="svc-price">${escapeText(card.pricePrefix || '')} <span>${escapeText(card.priceAmount)}</span> ${escapeText(card.priceSuffix || '')}</div>` : ''}
          ${card.linkText ? `<a href="${escapeAttr(card.linkUrl || '#')}" class="svc-link">${escapeText(card.linkText)}</a>` : ''}
        </div>
      </div>
    `).join('');
    return `
      <section id="${escapeAttr(id)}">
        <div class="container">
          ${c.label ? `<span class="section-label">${escapeText(c.label)}</span>` : ''}
          ${c.title ? `<h2 class="section-title">${formatItalics(c.title)}</h2>` : ''}
          <div class="services-grid">${cards}</div>
        </div>
      </section>
    `;
  },

  'feature-block'(c, id) {
    const stats = (c.stats || []).map(s => `
      <div>
        <div class="feature-stat-num">${escapeText(s.num || '')}</div>
        <div class="feature-stat-lbl">${escapeText(s.lbl || '')}</div>
      </div>
    `).join('');
    return `
      <section id="${escapeAttr(id)}" style="padding-top:20px;">
        <div class="container">
          <div class="feature-block">
            <div>
              ${c.label ? `<span class="section-label">${escapeText(c.label)}</span>` : ''}
              ${c.title ? `<h2 class="section-title">${formatItalics(c.title)}</h2>` : ''}
              ${c.body ? `<p>${escapeText(c.body)}</p>` : ''}
              ${stats ? `<div class="feature-stats">${stats}</div>` : ''}
              <div class="feature-actions">
                ${c.ctaPrimaryText ? `<a href="${escapeAttr(c.ctaPrimaryUrl || '#')}" class="btn-amber">${escapeText(c.ctaPrimaryText)}</a>` : ''}
                ${c.ctaSecondaryText ? `<a href="${escapeAttr(c.ctaSecondaryUrl || '#')}" class="btn-outline-cream">${escapeText(c.ctaSecondaryText)}</a>` : ''}
              </div>
            </div>
            <div class="feature-photo">
              ${c.image ? `<img src="${escapeAttr(c.image)}" alt="">` : ''}
            </div>
          </div>
        </div>
      </section>
    `;
  },

  'rate-list'(c, id) {
    const rates = (c.rates || []).map(r => `
      <div class="rate">
        <span class="rate-name">${escapeText(r.name || '')}</span>
        <span class="rate-price">${escapeText(r.price || '')}</span>
      </div>
    `).join('');
    return `
      <section id="${escapeAttr(id)}" style="background:var(--cream-soft); border-top:1px solid rgba(31,58,46,0.08); border-bottom:1px solid rgba(31,58,46,0.08);">
        <div class="container">
          <div class="facilities-wrap">
            <div>
              ${c.label ? `<span class="section-label">${escapeText(c.label)}</span>` : ''}
              ${c.title ? `<h2 class="section-title">${formatItalics(c.title)}</h2>` : ''}
              ${c.intro ? `<p style="color:var(--muted); font-size:17px;">${escapeText(c.intro)}</p>` : ''}
              <div class="rates-list">${rates}</div>
              ${c.ctaText ? `<a href="${escapeAttr(c.ctaUrl || '#')}" class="btn-primary">${escapeText(c.ctaText)} →</a>` : ''}
            </div>
            <div class="fac-photo">${c.image ? `<img src="${escapeAttr(c.image)}" alt="">` : ''}</div>
          </div>
        </div>
      </section>
    `;
  },

  'testimonial-grid'(c, id) {
    const t = (c.testimonials || []).map(x => `
      <div class="testimonial">
        <p class="testimonial-quote">${escapeText(x.quote || '')}</p>
        <div class="testimonial-author">
          <div class="avatar">${escapeText((x.name || '?').charAt(0).toUpperCase())}</div>
          <div>
            <div class="author-name">${escapeText(x.name || '')}</div>
            <div class="author-role">${escapeText(x.role || '')}</div>
          </div>
        </div>
      </div>
    `).join('');
    return `
      <section id="${escapeAttr(id)}">
        <div class="container">
          ${c.label ? `<span class="section-label">${escapeText(c.label)}</span>` : ''}
          ${c.title ? `<h2 class="section-title">${formatItalics(c.title)}</h2>` : ''}
          <div class="testimonials-grid">${t}</div>
        </div>
      </section>
    `;
  },

  'cta-strip'(c, id) {
    return `
      <div class="cta-strip" id="${escapeAttr(id)}">
        <div class="container">
          ${c.label ? `<span class="section-label">${escapeText(c.label)}</span>` : ''}
          ${c.title ? `<h2 class="section-title">${formatItalics(c.title)}</h2>` : ''}
          ${c.body ? `<p>${escapeText(c.body)}</p>` : ''}
          <div class="hero-actions">
            ${c.ctaPrimaryText ? `<a href="${escapeAttr(c.ctaPrimaryUrl || '#')}" class="btn-primary">${escapeText(c.ctaPrimaryText)}</a>` : ''}
            ${c.ctaSecondaryText ? `<a href="${escapeAttr(c.ctaSecondaryUrl || '#')}" class="btn-secondary">${escapeText(c.ctaSecondaryText)}</a>` : ''}
          </div>
        </div>
      </div>
    `;
  },

  gallery(c, id) {
    const items = (c.images || []).map(img => `
      <div class="gallery-item">
        ${img.src ? `<img src="${escapeAttr(img.src)}" alt="${escapeAttr(img.caption || '')}">` : ''}
        ${img.caption ? `<div class="gallery-caption">${escapeText(img.caption)}</div>` : ''}
      </div>
    `).join('');
    return `
      <section id="${escapeAttr(id)}">
        <div class="container">
          ${c.label ? `<span class="section-label">${escapeText(c.label)}</span>` : ''}
          ${c.title ? `<h2 class="section-title">${formatItalics(c.title)}</h2>` : ''}
          <div class="gallery-grid">${items}</div>
        </div>
      </section>
    `;
  },

  'announcement-banner'(c, id) {
    // Rendered separately at very top
    return '';
  },

  'video-embed'(c, id) {
    return `
      <section id="${escapeAttr(id)}">
        <div class="container">
          ${c.label ? `<span class="section-label">${escapeText(c.label)}</span>` : ''}
          ${c.title ? `<h2 class="section-title">${formatItalics(c.title)}</h2>` : ''}
          ${c.youtubeId ? `<div class="video-wrap"><iframe src="https://www.youtube.com/embed/${escapeAttr(c.youtubeId)}" allowfullscreen></iframe></div>` : ''}
        </div>
      </section>
    `;
  }
};

// Announcement banner rendered outside the sections stream (fixed to top)
function renderAnnouncement(sections) {
  const banner = sections.find(s => s.type === 'announcement-banner' && s.visible !== false);
  const slot = document.getElementById('announcement-slot');
  if (!banner) { slot.innerHTML = ''; return; }
  const c = banner.content || {};
  slot.innerHTML = `
    <div class="announcement">
      ${escapeText(c.text || '')}
      ${c.ctaText ? `<a href="${escapeAttr(c.ctaUrl || '#')}">${escapeText(c.ctaText)} →</a>` : ''}
    </div>
  `;
}

function renderFooter(footer) {
  const slot = document.getElementById('footer-slot');
  if (!footer) { slot.innerHTML = ''; return; }
  const cols = (footer.columns || []).map(col => `
    <div class="footer-col">
      <h4>${escapeText(col.heading || '')}</h4>
      <ul>
        ${(col.links || []).map(l => `<li><a href="${escapeAttr(l.url)}">${escapeText(l.text)}</a></li>`).join('')}
      </ul>
    </div>
  `).join('');
  const year = new Date().getFullYear();
  const copyright = (footer.copyrightText || '').replace('{year}', year);
  slot.innerHTML = `
    <footer class="site">
      <div class="container">
        <div class="footer-grid">
          <div class="footer-brand">
            <h3>The Treble Makers</h3>
            ${footer.brandTagline ? `<div class="tagline">${escapeText(footer.brandTagline)}</div>` : ''}
            ${footer.address ? `<address>${escapeText(footer.address)}</address>` : ''}
          </div>
          ${cols}
          ${footer.newsletterHeading ? `
            <div class="footer-col">
              <h4>${escapeText(footer.newsletterHeading)}</h4>
              <p style="font-size:14px;">${escapeText(footer.newsletterText || '')}</p>
            </div>
          ` : ''}
        </div>
        <div class="footer-bottom">
          <div>${escapeText(copyright)}</div>
        </div>
      </div>
    </footer>
  `;
}

// --- Helpers ---

function escapeText(s) {
  if (s == null) return '';
  return String(s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
function escapeAttr(s) { return escapeText(s); }

// *word* → <em>word</em> (Markdown-lite for italics in titles)
function formatItalics(s) {
  return escapeText(s).replace(/\*([^*]+)\*/g, '<em>$1</em>');
}

loadPage();
