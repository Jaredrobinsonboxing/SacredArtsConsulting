// Section template library.
// Each template defines: display name, editable fields, and (implicitly, in public.js) a renderer.
// Field types: text, textarea, image, url, list, select
// Fields can be optional (marked with `optional: true`).

export const TEMPLATES = {
  hero: {
    name: 'Hero',
    description: 'Big opening block with headline, subtitle, buttons, and photos.',
    fields: [
      { key: 'eyebrow', label: 'Eyebrow (small tagline above title)', type: 'text' },
      { key: 'title', label: 'Title (use * around words to italicize)', type: 'textarea' },
      { key: 'sub', label: 'Subtitle', type: 'textarea' },
      { key: 'ctaPrimaryText', label: 'Primary button text', type: 'text' },
      { key: 'ctaPrimaryUrl', label: 'Primary button link', type: 'url' },
      { key: 'ctaSecondaryText', label: 'Secondary button text', type: 'text', optional: true },
      { key: 'ctaSecondaryUrl', label: 'Secondary button link', type: 'url', optional: true },
      { key: 'photoMain', label: 'Main photo', type: 'image' },
      { key: 'photoSecondary', label: 'Second photo', type: 'image', optional: true },
      { key: 'badgeTop', label: 'Circle badge — top line (large)', type: 'text', optional: true },
      { key: 'badgeBottom', label: 'Circle badge — bottom line', type: 'text', optional: true }
    ]
  },

  'trust-bar': {
    name: 'Trust Bar',
    description: 'Dark strip with credentials and trust signals.',
    fields: [
      { key: 'items', label: 'Trust items', type: 'list', itemFields: [
        { key: 'text', label: 'Text', type: 'text' }
      ]}
    ]
  },

  'text-block': {
    name: 'Text Block',
    description: 'A simple heading + paragraph section.',
    fields: [
      { key: 'label', label: 'Section label (small)', type: 'text', optional: true },
      { key: 'title', label: 'Title', type: 'textarea' },
      { key: 'body', label: 'Body', type: 'textarea' }
    ]
  },

  'image-text': {
    name: 'Image + Text',
    description: 'Photo on one side, text and a button on the other.',
    fields: [
      { key: 'image', label: 'Image', type: 'image' },
      { key: 'imagePosition', label: 'Image position', type: 'select', options: ['left', 'right'] },
      { key: 'label', label: 'Section label', type: 'text', optional: true },
      { key: 'title', label: 'Title', type: 'textarea' },
      { key: 'body', label: 'Body', type: 'textarea' },
      { key: 'ctaText', label: 'Button text', type: 'text', optional: true },
      { key: 'ctaUrl', label: 'Button link', type: 'url', optional: true }
    ]
  },

  timeline: {
    name: 'Life Stage Timeline',
    description: 'Horizontal age-stage bar — the signature element.',
    fields: [
      { key: 'label', label: 'Section label', type: 'text' },
      { key: 'title', label: 'Title', type: 'textarea' },
      { key: 'lede', label: 'Intro sentence', type: 'textarea' },
      { key: 'stages', label: 'Stages (each column on the timeline)', type: 'list', itemFields: [
        { key: 'age', label: 'Age range (e.g. "4mo – 2yr")', type: 'text' },
        { key: 'label', label: 'Stage name', type: 'text' },
        { key: 'desc', label: 'Short description', type: 'textarea' }
      ]}
    ]
  },

  services: {
    name: 'Services Grid',
    description: 'Cards with photo, title, description, and price.',
    fields: [
      { key: 'label', label: 'Section label', type: 'text' },
      { key: 'title', label: 'Title', type: 'textarea' },
      { key: 'cards', label: 'Service cards', type: 'list', itemFields: [
        { key: 'image', label: 'Card image', type: 'image' },
        { key: 'tag', label: 'Tag (top-left pill)', type: 'text' },
        { key: 'title', label: 'Card title', type: 'text' },
        { key: 'desc', label: 'Description', type: 'textarea' },
        { key: 'pricePrefix', label: 'Price prefix (e.g. "From")', type: 'text', optional: true },
        { key: 'priceAmount', label: 'Price amount (e.g. "$60")', type: 'text', optional: true },
        { key: 'priceSuffix', label: 'Price suffix (e.g. "/ session")', type: 'text', optional: true },
        { key: 'linkText', label: 'Link text', type: 'text' },
        { key: 'linkUrl', label: 'Link URL', type: 'url' }
      ]}
    ]
  },

  'feature-block': {
    name: 'Feature Block',
    description: 'Dark spotlighted block with headline, stats, image, and CTAs. (Hudson Smiles style.)',
    fields: [
      { key: 'label', label: 'Section label', type: 'text' },
      { key: 'title', label: 'Title', type: 'textarea' },
      { key: 'body', label: 'Body', type: 'textarea' },
      { key: 'stats', label: 'Stats (up to 3)', type: 'list', itemFields: [
        { key: 'num', label: 'Number/word', type: 'text' },
        { key: 'lbl', label: 'Label under it', type: 'text' }
      ]},
      { key: 'ctaPrimaryText', label: 'Primary button', type: 'text' },
      { key: 'ctaPrimaryUrl', label: 'Primary link', type: 'url' },
      { key: 'ctaSecondaryText', label: 'Secondary button', type: 'text', optional: true },
      { key: 'ctaSecondaryUrl', label: 'Secondary link', type: 'url', optional: true },
      { key: 'image', label: 'Photo', type: 'image' }
    ]
  },

  'rate-list': {
    name: 'Rate List',
    description: 'Two-column layout with a photo and a price list.',
    fields: [
      { key: 'label', label: 'Section label', type: 'text' },
      { key: 'title', label: 'Title', type: 'textarea' },
      { key: 'intro', label: 'Intro paragraph', type: 'textarea' },
      { key: 'rates', label: 'Line items', type: 'list', itemFields: [
        { key: 'name', label: 'Service', type: 'text' },
        { key: 'price', label: 'Price', type: 'text' }
      ]},
      { key: 'ctaText', label: 'Button text', type: 'text' },
      { key: 'ctaUrl', label: 'Button link', type: 'url' },
      { key: 'image', label: 'Photo', type: 'image' }
    ]
  },

  'testimonial-grid': {
    name: 'Testimonials',
    description: 'Grid of quote cards.',
    fields: [
      { key: 'label', label: 'Section label', type: 'text' },
      { key: 'title', label: 'Title', type: 'textarea' },
      { key: 'testimonials', label: 'Testimonials', type: 'list', itemFields: [
        { key: 'quote', label: 'Quote', type: 'textarea' },
        { key: 'name', label: 'Name', type: 'text' },
        { key: 'role', label: 'Role/location', type: 'text' }
      ]}
    ]
  },

  'cta-strip': {
    name: 'Call-to-Action Strip',
    description: 'Full-width sage-green band with title and buttons.',
    fields: [
      { key: 'label', label: 'Section label', type: 'text' },
      { key: 'title', label: 'Title', type: 'textarea' },
      { key: 'body', label: 'Body', type: 'textarea' },
      { key: 'ctaPrimaryText', label: 'Primary button', type: 'text' },
      { key: 'ctaPrimaryUrl', label: 'Primary link', type: 'url' },
      { key: 'ctaSecondaryText', label: 'Secondary button', type: 'text', optional: true },
      { key: 'ctaSecondaryUrl', label: 'Secondary link', type: 'url', optional: true }
    ]
  },

  gallery: {
    name: 'Image Gallery',
    description: 'A row of images with optional captions.',
    fields: [
      { key: 'label', label: 'Section label', type: 'text', optional: true },
      { key: 'title', label: 'Title', type: 'text', optional: true },
      { key: 'images', label: 'Photos', type: 'list', itemFields: [
        { key: 'src', label: 'Image', type: 'image' },
        { key: 'caption', label: 'Caption', type: 'text', optional: true }
      ]}
    ]
  },

  'announcement-banner': {
    name: 'Announcement Banner',
    description: 'Thin colored strip at top for time-sensitive news.',
    fields: [
      { key: 'text', label: 'Announcement text', type: 'text' },
      { key: 'ctaText', label: 'Button text', type: 'text', optional: true },
      { key: 'ctaUrl', label: 'Button link', type: 'url', optional: true }
    ]
  },

  'video-embed': {
    name: 'Video Embed',
    description: 'A YouTube video.',
    fields: [
      { key: 'label', label: 'Section label', type: 'text', optional: true },
      { key: 'title', label: 'Title', type: 'text', optional: true },
      { key: 'youtubeId', label: 'YouTube video ID (from the URL)', type: 'text' }
    ]
  }
};

// Site-wide config (not a section — edited from Site Settings)
export const SITE_CONFIG_SCHEMA = {
  nav: {
    fields: [
      { key: 'brand', label: 'Brand name', type: 'text' },
      { key: 'links', label: 'Menu links', type: 'list', itemFields: [
        { key: 'text', label: 'Link text', type: 'text' },
        { key: 'url', label: 'URL (use #section-id for anchors)', type: 'text' }
      ]},
      { key: 'ctaText', label: 'CTA button text', type: 'text' },
      { key: 'ctaUrl', label: 'CTA button link', type: 'url' }
    ]
  },
  footer: {
    fields: [
      { key: 'brandTagline', label: 'Brand tagline (script)', type: 'text' },
      { key: 'address', label: 'Address (line breaks allowed)', type: 'textarea' },
      { key: 'columns', label: 'Link columns', type: 'list', itemFields: [
        { key: 'heading', label: 'Column heading', type: 'text' },
        { key: 'links', label: 'Links', type: 'list', itemFields: [
          { key: 'text', label: 'Link text', type: 'text' },
          { key: 'url', label: 'URL', type: 'text' }
        ]}
      ]},
      { key: 'newsletterHeading', label: 'Newsletter heading', type: 'text' },
      { key: 'newsletterText', label: 'Newsletter text', type: 'textarea' },
      { key: 'copyrightText', label: 'Copyright text', type: 'text' }
    ]
  }
};
