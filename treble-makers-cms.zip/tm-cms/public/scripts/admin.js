import { TEMPLATES, SITE_CONFIG_SCHEMA } from './schemas.js';

const PAGE_ID = 'home';
const state = {
  loggedIn: false,
  page: null,        // full page doc
  view: 'sections',  // 'sections' | 'site-settings' | 'history'
  activeSectionId: null,
  saveTimer: null,
  saving: false
};

const app = document.getElementById('app');

// --- Boot ---

async function boot() {
  // Try to load content — if 401, show login; if 200, we're already authed
  const res = await fetch(`/api/content/${PAGE_ID}`);
  if (res.ok) {
    const data = await res.json();
    // history included only if authed
    state.loggedIn = 'history' in data;
    if (state.loggedIn) {
      state.page = data;
      renderAdmin();
    } else {
      renderLogin();
    }
  } else {
    renderLogin();
  }
}

// --- Login ---

function renderLogin(errorMsg) {
  app.innerHTML = `
    <div class="login-screen">
      <div class="login-card">
        <h1>Treble Makers Admin</h1>
        <p>Sign in to edit the site.</p>
        <form id="login-form">
          <input type="password" id="login-pwd" placeholder="Password" autocomplete="current-password" autofocus required>
          <button type="submit">Sign in</button>
          ${errorMsg ? `<div class="login-error">${escapeText(errorMsg)}</div>` : ''}
        </form>
      </div>
    </div>
  `;
  document.getElementById('login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const password = document.getElementById('login-pwd').value;
    try {
      const res = await fetch('/api/login', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ password })
      });
      if (res.ok) {
        state.loggedIn = true;
        await loadPage();
        renderAdmin();
      } else {
        const err = await res.json();
        renderLogin(err.error || 'Sign-in failed');
      }
    } catch (err) {
      renderLogin('Network error. Try again.');
    }
  });
}

async function logout() {
  await fetch('/api/logout', { method: 'POST' });
  state.loggedIn = false;
  state.page = null;
  renderLogin();
}

async function loadPage() {
  const res = await fetch(`/api/content/${PAGE_ID}`);
  if (res.ok) state.page = await res.json();
}

// --- Admin shell ---

function renderAdmin() {
  if (!state.page) {
    app.innerHTML = '<div class="login-screen"><div class="login-card">Loading…</div></div>';
    return;
  }
  app.innerHTML = `
    <div class="admin">
      <aside class="sidebar">
        <div class="side-brand">Treble Makers</div>
        <div class="side-sub">Site admin</div>
        <div class="side-nav">
          <button data-view="sections" class="${state.view === 'sections' ? 'active' : ''}">Sections</button>
          <button data-view="site-settings" class="${state.view === 'site-settings' ? 'active' : ''}">Site settings</button>
          <button data-view="history" class="${state.view === 'history' ? 'active' : ''}">History</button>
        </div>
        ${state.view === 'sections' ? renderSectionList() : ''}
        <div class="sidebar-actions">
          <button data-action="view-site">View public site ↗</button>
          <button data-action="logout">Sign out</button>
        </div>
      </aside>
      <main class="editor">
        <div class="editor-header">
          <div class="editor-title">${editorTitle()}</div>
          <div class="editor-actions">
            <span id="save-status"><span class="status-dot" id="save-dot"></span><span id="save-text">Saved</span></span>
          </div>
        </div>
        <div id="editor-body">${renderEditorBody()}</div>
      </main>
    </div>
  `;
  wireSidebar();
  wireEditor();
}

function editorTitle() {
  if (state.view === 'site-settings') return 'Site settings (nav + footer)';
  if (state.view === 'history') return 'Edit history';
  if (state.activeSectionId) {
    const s = getSection(state.activeSectionId);
    return s ? `Edit ${TEMPLATES[s.type]?.name || s.type}` : 'Section not found';
  }
  return 'Sections';
}

function renderSectionList() {
  const sections = state.page.current.sections || [];
  const items = sections.map(s => {
    const tpl = TEMPLATES[s.type];
    const isActive = s.id === state.activeSectionId;
    const hiddenClass = s.visible === false ? 'hidden' : '';
    const contentName = s.content?.title?.slice(0, 30) || tpl?.name || s.type;
    return `
      <li class="section-item ${isActive ? 'active' : ''} ${hiddenClass}" data-id="${escapeAttr(s.id)}">
        <span class="grip">⋮⋮</span>
        <span class="name">${escapeText(contentName)}</span>
        <span class="type-tag">${escapeText(tpl?.name || s.type)}</span>
      </li>
    `;
  }).join('');
  return `
    <div class="section-list-title">Page sections</div>
    <ul class="section-list" id="section-list">${items}</ul>
    <button class="add-section-btn" data-action="add-section">+ Add section</button>
  `;
}

function renderEditorBody() {
  if (state.view === 'site-settings') return renderSiteSettings();
  if (state.view === 'history') return renderHistoryPanel();
  if (state.activeSectionId) return renderSectionEditor(state.activeSectionId);
  const count = state.page.current.sections?.length || 0;
  return `
    <div class="form-panel">
      <h3>Pick a section to edit</h3>
      <p class="form-desc">This page has ${count} section${count === 1 ? '' : 's'}. Click one in the sidebar, or drag to reorder them. Every save goes live immediately, and the last 30 days of edits are kept as recoverable history.</p>
    </div>
  `;
}

// --- Section editor ---

function renderSectionEditor(id) {
  const s = getSection(id);
  if (!s) return '<div class="form-panel">Section not found.</div>';
  const tpl = TEMPLATES[s.type];
  if (!tpl) return `<div class="form-panel">Unknown template: ${escapeText(s.type)}</div>`;

  const isHidden = s.visible === false;
  return `
    <div class="form-panel">
      <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:16px; gap:16px;">
        <div>
          <h3>${escapeText(tpl.name)}</h3>
          <div class="form-desc">${escapeText(tpl.description || '')}</div>
        </div>
        <div style="display:flex; gap:6px; flex-wrap:wrap;">
          <button class="btn btn-sm" data-action="toggle-visible" data-id="${escapeAttr(id)}">
            ${isHidden ? '👁 Show' : '👁 Hide'}
          </button>
          <button class="btn btn-sm" data-action="duplicate" data-id="${escapeAttr(id)}">Duplicate</button>
          <button class="btn btn-sm btn-danger" data-action="delete" data-id="${escapeAttr(id)}">Delete</button>
        </div>
      </div>
      <form id="section-form" data-id="${escapeAttr(id)}">
        ${tpl.fields.map(f => renderField(f, s.content?.[f.key], `content.${f.key}`)).join('')}
      </form>
    </div>
  `;
}

function renderField(field, value, path) {
  const label = `${escapeText(field.label)}${field.optional ? ' <span class="optional">(optional)</span>' : ''}`;
  const id = `f_${path.replace(/\W/g, '_')}`;

  switch (field.type) {
    case 'text':
      return `
        <div class="field">
          <label for="${id}">${label}</label>
          <input type="text" id="${id}" data-path="${escapeAttr(path)}" value="${escapeAttr(value ?? '')}">
        </div>
      `;
    case 'url':
      return `
        <div class="field">
          <label for="${id}">${label}</label>
          <input type="url" id="${id}" data-path="${escapeAttr(path)}" value="${escapeAttr(value ?? '')}" placeholder="https://...">
        </div>
      `;
    case 'textarea':
      return `
        <div class="field">
          <label for="${id}">${label}</label>
          <textarea id="${id}" data-path="${escapeAttr(path)}">${escapeText(value ?? '')}</textarea>
        </div>
      `;
    case 'select':
      return `
        <div class="field">
          <label for="${id}">${label}</label>
          <select id="${id}" data-path="${escapeAttr(path)}">
            ${(field.options || []).map(o => `<option value="${escapeAttr(o)}" ${o === value ? 'selected' : ''}>${escapeText(o)}</option>`).join('')}
          </select>
        </div>
      `;
    case 'image':
      return `
        <div class="field field-image">
          <label>${label}</label>
          <div class="image-preview" style="${value ? `background-image:url('${escapeAttr(value)}')` : ''}">
            ${value ? '' : 'No image'}
          </div>
          <div class="image-controls">
            <input type="text" data-path="${escapeAttr(path)}" value="${escapeAttr(value ?? '')}" placeholder="Paste image URL or upload">
            <input type="file" class="file-input" accept="image/*" data-target-path="${escapeAttr(path)}">
            <button type="button" class="btn btn-sm" data-action="upload-image" data-target-path="${escapeAttr(path)}">Upload</button>
          </div>
        </div>
      `;
    case 'list':
      return renderListField(field, value || [], path);
    default:
      return `<div class="field">Unknown field type: ${field.type}</div>`;
  }
}

function renderListField(field, items, path) {
  return `
    <div class="field">
      <label>${escapeText(field.label)}</label>
      <div class="list-field" data-list-path="${escapeAttr(path)}">
        ${items.map((item, i) => `
          <div class="list-item" data-index="${i}">
            <div class="list-item-header">
              <span class="grip">⋮⋮</span>
              <span class="list-item-title">${escapeText(itemTitle(item, field.itemFields, i))}</span>
              <button type="button" class="btn btn-sm btn-danger" data-action="remove-list-item" data-list-path="${escapeAttr(path)}" data-index="${i}">Remove</button>
            </div>
            ${field.itemFields.map(f => renderField(f, item[f.key], `${path}[${i}].${f.key}`)).join('')}
          </div>
        `).join('')}
        <button type="button" class="list-add-btn" data-action="add-list-item" data-list-path="${escapeAttr(path)}" data-item-fields='${escapeAttr(JSON.stringify(field.itemFields))}'>
          + Add item
        </button>
      </div>
    </div>
  `;
}

function itemTitle(item, fields, i) {
  const preferred = fields.find(f => ['title', 'name', 'text', 'heading', 'age', 'quote'].includes(f.key));
  const val = preferred ? item[preferred.key] : null;
  return val ? String(val).slice(0, 60) : `Item ${i + 1}`;
}

// --- Site settings ---

function renderSiteSettings() {
  const nav = state.page.current.nav || {};
  const footer = state.page.current.footer || {};
  return `
    <div class="form-panel" style="margin-bottom:16px;">
      <h3>Navigation</h3>
      <div class="form-desc">The header shown at the top of every page.</div>
      <form id="nav-form">
        ${SITE_CONFIG_SCHEMA.nav.fields.map(f => renderField(f, nav[f.key], `nav.${f.key}`)).join('')}
      </form>
    </div>
    <div class="form-panel">
      <h3>Footer</h3>
      <div class="form-desc">Shown at the bottom of every page. Use <code>{year}</code> in the copyright to auto-fill the current year.</div>
      <form id="footer-form">
        ${SITE_CONFIG_SCHEMA.footer.fields.map(f => renderField(f, footer[f.key], `footer.${f.key}`)).join('')}
      </form>
    </div>
  `;
}

// --- History panel ---

function renderHistoryPanel() {
  const history = state.page.history || [];
  if (!history.length) {
    return `<div class="form-panel"><h3>No history yet</h3><p class="form-desc">Once you make edits, previous versions appear here. Anything older than 30 days is dropped automatically.</p></div>`;
  }
  return `
    <div class="form-panel">
      <h3>Edit history</h3>
      <p class="form-desc">The last 30 days of edits, newest first. Restore replaces the current version — the current version is snapshotted into history first, so you can undo the restore.</p>
      <ul class="history-list">
        ${history.map(h => `
          <li class="history-entry">
            <div>
              <div class="history-time">${formatTime(h.timestamp)}</div>
              <div class="history-meta">${h.sectionCount} section${h.sectionCount === 1 ? '' : 's'}</div>
            </div>
            <button class="btn btn-sm" data-action="restore" data-timestamp="${escapeAttr(h.timestamp)}">Restore</button>
          </li>
        `).join('')}
      </ul>
    </div>
  `;
}

function formatTime(iso) {
  const d = new Date(iso);
  return d.toLocaleString(undefined, {
    month: 'short', day: 'numeric', year: 'numeric',
    hour: 'numeric', minute: '2-digit'
  });
}

// --- Event wiring ---

function wireSidebar() {
  document.querySelectorAll('[data-view]').forEach(btn => {
    btn.addEventListener('click', () => {
      state.view = btn.dataset.view;
      state.activeSectionId = null;
      renderAdmin();
    });
  });

  document.querySelectorAll('[data-action="logout"]').forEach(b => b.addEventListener('click', logout));
  document.querySelectorAll('[data-action="view-site"]').forEach(b => b.addEventListener('click', () => window.open('/', '_blank')));

  document.querySelectorAll('[data-action="add-section"]').forEach(b => b.addEventListener('click', openAddModal));

  const list = document.getElementById('section-list');
  if (list) {
    list.querySelectorAll('.section-item').forEach(item => {
      item.addEventListener('click', () => {
        state.activeSectionId = item.dataset.id;
        state.view = 'sections';
        renderAdmin();
      });
    });
    // Drag-to-reorder
    Sortable.create(list, {
      handle: '.grip',
      animation: 150,
      onEnd: (evt) => {
        const sections = state.page.current.sections;
        const [moved] = sections.splice(evt.oldIndex, 1);
        sections.splice(evt.newIndex, 0, moved);
        sections.forEach((s, i) => s.order = i);
        scheduleSave();
      }
    });
  }
}

function wireEditor() {
  const body = document.getElementById('editor-body');

  // Field changes (debounced save)
  body.addEventListener('input', (e) => {
    const el = e.target;
    if (el.dataset.path) {
      const path = el.dataset.path;
      const val = el.value;
      setDeep(getEditingRoot(), path, val);
      updateFieldSideEffects(el, path, val);
      scheduleSave();
    }
  });
  body.addEventListener('change', (e) => {
    if (e.target.tagName === 'SELECT' && e.target.dataset.path) {
      setDeep(getEditingRoot(), e.target.dataset.path, e.target.value);
      scheduleSave();
    }
    if (e.target.type === 'file' && e.target.dataset.targetPath) {
      handleFileUpload(e.target);
    }
  });

  // Buttons
  body.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-action]');
    if (!btn) return;
    const action = btn.dataset.action;

    if (action === 'delete') deleteSection(btn.dataset.id);
    else if (action === 'duplicate') duplicateSection(btn.dataset.id);
    else if (action === 'toggle-visible') toggleVisible(btn.dataset.id);
    else if (action === 'add-list-item') addListItem(btn.dataset.listPath, JSON.parse(btn.dataset.itemFields));
    else if (action === 'remove-list-item') removeListItem(btn.dataset.listPath, parseInt(btn.dataset.index, 10));
    else if (action === 'upload-image') {
      const fileInput = btn.parentElement.querySelector('input[type="file"]');
      fileInput.click();
    }
    else if (action === 'restore') restoreVersion(btn.dataset.timestamp);
  });
}

function updateFieldSideEffects(el, path, val) {
  // Update image preview live when URL field changes
  if (el.type === 'text' && el.closest('.field-image')) {
    const preview = el.closest('.field-image').querySelector('.image-preview');
    if (preview) {
      if (val) {
        preview.style.backgroundImage = `url('${val}')`;
        preview.textContent = '';
      } else {
        preview.style.backgroundImage = '';
        preview.textContent = 'No image';
      }
    }
  }
}

async function handleFileUpload(fileInput) {
  const file = fileInput.files?.[0];
  if (!file) return;
  const path = fileInput.dataset.targetPath;

  if (file.size > 5 * 1024 * 1024) {
    toast('Image too large (max 5MB)', 'error');
    return;
  }

  toast('Uploading…');
  try {
    const b64 = await fileToBase64(file);
    const res = await fetch('/api/upload', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        filename: file.name,
        contentType: file.type,
        data: b64
      })
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Upload failed');
    }
    const { url } = await res.json();
    setDeep(getEditingRoot(), path, url);
    // Update the text input + preview
    const textInput = fileInput.parentElement.querySelector('input[type="text"]');
    if (textInput) {
      textInput.value = url;
      updateFieldSideEffects(textInput, path, url);
    }
    scheduleSave();
    toast('Uploaded');
  } catch (err) {
    toast(err.message || 'Upload failed', 'error');
  } finally {
    fileInput.value = '';
  }
}

function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result;
      resolve(dataUrl.split(',')[1]);
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

// --- Section operations ---

function getSection(id) {
  return state.page.current.sections.find(s => s.id === id);
}

function getEditingRoot() {
  if (state.view === 'sections' && state.activeSectionId) {
    return getSection(state.activeSectionId);
  }
  return state.page.current;
}

function deleteSection(id) {
  const s = getSection(id);
  if (!s) return;
  const tpl = TEMPLATES[s.type];
  if (!confirm(`Delete "${tpl?.name || s.type}"? This can be undone from History for 30 days.`)) return;
  state.page.current.sections = state.page.current.sections.filter(x => x.id !== id);
  state.page.current.sections.forEach((s, i) => s.order = i);
  if (state.activeSectionId === id) state.activeSectionId = null;
  save();
  renderAdmin();
}

function duplicateSection(id) {
  const s = getSection(id);
  if (!s) return;
  const copy = JSON.parse(JSON.stringify(s));
  copy.id = generateId();
  const idx = state.page.current.sections.findIndex(x => x.id === id);
  state.page.current.sections.splice(idx + 1, 0, copy);
  state.page.current.sections.forEach((s, i) => s.order = i);
  state.activeSectionId = copy.id;
  save();
  renderAdmin();
}

function toggleVisible(id) {
  const s = getSection(id);
  if (!s) return;
  s.visible = !(s.visible !== false);
  save();
  renderAdmin();
}

function addListItem(listPath, itemFields) {
  const blank = {};
  itemFields.forEach(f => {
    if (f.type === 'list') blank[f.key] = [];
    else blank[f.key] = '';
  });
  const arr = getDeep(getEditingRoot(), listPath) || [];
  arr.push(blank);
  setDeep(getEditingRoot(), listPath, arr);
  save();
  renderAdmin();
}

function removeListItem(listPath, index) {
  const arr = getDeep(getEditingRoot(), listPath);
  if (!Array.isArray(arr)) return;
  arr.splice(index, 1);
  setDeep(getEditingRoot(), listPath, arr);
  save();
  renderAdmin();
}

// --- Add section modal ---

function openAddModal() {
  const modal = document.createElement('div');
  modal.className = 'modal-backdrop';
  modal.innerHTML = `
    <div class="modal">
      <h2>Add a section</h2>
      <p>Pick a template. You can edit it after adding.</p>
      <div class="template-grid">
        ${Object.entries(TEMPLATES).map(([key, tpl]) => `
          <button class="template-card" data-template="${escapeAttr(key)}">
            <div class="t-name">${escapeText(tpl.name)}</div>
            <div class="t-desc">${escapeText(tpl.description || '')}</div>
          </button>
        `).join('')}
      </div>
      <div class="modal-actions">
        <button class="btn" data-close>Cancel</button>
      </div>
    </div>
  `;
  document.body.appendChild(modal);
  modal.addEventListener('click', (e) => {
    if (e.target === modal || e.target.dataset.close !== undefined) {
      document.body.removeChild(modal);
      return;
    }
    const card = e.target.closest('[data-template]');
    if (card) {
      addSection(card.dataset.template);
      document.body.removeChild(modal);
    }
  });
}

function addSection(templateType) {
  const tpl = TEMPLATES[templateType];
  if (!tpl) return;
  const blank = { id: generateId(), type: templateType, order: state.page.current.sections.length, visible: true, content: {} };
  tpl.fields.forEach(f => {
    if (f.type === 'list') blank.content[f.key] = [];
    else blank.content[f.key] = '';
  });
  state.page.current.sections.push(blank);
  state.activeSectionId = blank.id;
  save();
  renderAdmin();
}

// --- History restore ---

async function restoreVersion(timestamp) {
  if (!confirm('Restore this version? Your current version will be snapshotted so you can undo.')) return;
  try {
    const res = await fetch('/api/restore', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ pageId: PAGE_ID, timestamp })
    });
    if (!res.ok) throw new Error('Restore failed');
    await loadPage();
    state.view = 'sections';
    state.activeSectionId = null;
    renderAdmin();
    toast('Version restored');
  } catch (err) {
    toast(err.message, 'error');
  }
}

// --- Save (debounced) ---

function scheduleSave() {
  if (state.saveTimer) clearTimeout(state.saveTimer);
  setStatus('saving');
  state.saveTimer = setTimeout(save, 800);
}

async function save() {
  if (state.saveTimer) { clearTimeout(state.saveTimer); state.saveTimer = null; }
  if (state.saving) { scheduleSave(); return; }
  state.saving = true;
  setStatus('saving');
  try {
    const res = await fetch(`/api/content/${PAGE_ID}`, {
      method: 'PUT',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ current: state.page.current })
    });
    if (!res.ok) {
      if (res.status === 401) {
        state.loggedIn = false;
        renderLogin('Session expired. Sign in again.');
        return;
      }
      throw new Error('Save failed');
    }
    const { updatedAt } = await res.json();
    state.page.updatedAt = updatedAt;
    setStatus('saved');
  } catch (err) {
    setStatus('error');
    toast(err.message || 'Save failed', 'error');
  } finally {
    state.saving = false;
  }
}

function setStatus(status) {
  const dot = document.getElementById('save-dot');
  const text = document.getElementById('save-text');
  if (!dot || !text) return;
  dot.className = 'status-dot' + (status === 'saving' ? ' saving' : status === 'error' ? ' error' : '');
  text.textContent = status === 'saving' ? 'Saving…' : status === 'error' ? 'Error' : 'Saved';
}

// --- Toast ---

function toast(msg, type) {
  const el = document.createElement('div');
  el.className = 'toast' + (type === 'error' ? ' error' : '');
  el.textContent = msg;
  document.body.appendChild(el);
  setTimeout(() => { el.style.opacity = 0; el.style.transition = 'opacity 0.2s'; }, 2200);
  setTimeout(() => document.body.removeChild(el), 2500);
}

// --- Utils ---

function generateId() {
  return 'sec_' + Math.random().toString(36).slice(2, 10);
}

function escapeText(s) {
  if (s == null) return '';
  return String(s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
function escapeAttr(s) { return escapeText(s); }

// Simple path get/set — supports "a.b[0].c"
function getDeep(obj, path) {
  const parts = pathParts(path);
  let cur = obj;
  for (const p of parts) {
    if (cur == null) return undefined;
    cur = cur[p];
  }
  return cur;
}

function setDeep(obj, path, value) {
  const parts = pathParts(path);
  let cur = obj;
  for (let i = 0; i < parts.length - 1; i++) {
    const p = parts[i];
    if (cur[p] == null) {
      cur[p] = typeof parts[i + 1] === 'number' ? [] : {};
    }
    cur = cur[p];
  }
  cur[parts[parts.length - 1]] = value;
}

function pathParts(path) {
  const parts = [];
  path.split('.').forEach(seg => {
    const m = seg.match(/^([^[]+)(\[(\d+)\])?$/);
    if (!m) return;
    parts.push(m[1]);
    if (m[3] !== undefined) parts.push(parseInt(m[3], 10));
  });
  return parts;
}

boot();
