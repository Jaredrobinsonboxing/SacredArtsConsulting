#!/usr/bin/env node
// Usage: npm run hash-password
// Prompts for a password and prints the bcrypt hash to paste as ADMIN_PASSWORD_HASH.

import bcrypt from 'bcryptjs';
import readline from 'node:readline';

const rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: true });

// Hide input as user types (crude but works)
rl.question('New admin password: ', async (password) => {
  if (!password || password.length < 8) {
    console.error('\nPassword must be at least 8 characters.');
    rl.close();
    process.exit(1);
  }
  const hash = await bcrypt.hash(password, 12);
  console.log('\nADMIN_PASSWORD_HASH:');
  console.log(hash);
  console.log('\nPaste this as the ADMIN_PASSWORD_HASH env var in Netlify → Site settings → Environment variables.');
  rl.close();
});
