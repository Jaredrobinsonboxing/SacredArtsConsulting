#!/usr/bin/env node
// Initial content for the home page.
// Two ways to use:
//   1. Run against your live site once deployed:
//      SITE_URL=https://your-site.netlify.app ADMIN_PASSWORD=xxx node scripts/seed-content.mjs
//   2. Copy the JSON below into Netlify Blobs manually.
//
// After first deploy the /admin UI takes over from here — this only bootstraps day 0.

import { readFileSync } from 'node:fs';

const seed = {
  pageId: 'home',
  updatedAt: new Date().toISOString(),
  current: {
    nav: {
      brand: 'The Treble Makers',
      links: [
        { text: 'Services', url: '#services' },
        { text: 'Facilities', url: '#facilities' },
        { text: 'Hudson Smiles', url: '#hudson' },
        { text: 'About', url: '#about' },
        { text: 'Contact', url: '#contact' }
      ],
      ctaText: 'Book',
      ctaUrl: 'http://thetreblemakers.as.me'
    },
    sections: [
      {
        id: 'sec_hero',
        type: 'hero',
        order: 0,
        visible: true,
        content: {
          eyebrow: 'Rooted in music, growing together',
          title: 'Connection\nthrough *music.*',
          sub: 'Board-certified music therapy for infants through seniors — meeting each person where they are, and using music to help them get where they\'re going.',
          ctaPrimaryText: 'Find your fit',
          ctaPrimaryUrl: '#services',
          ctaSecondaryText: 'Book an intake',
          ctaSecondaryUrl: 'http://thetreblemakers.as.me',
          photoMain: '',    // fill after upload via admin
          photoSecondary: '',
          badgeTop: '4mo–99+',
          badgeBottom: 'we serve every stage of life'
        }
      },
      {
        id: 'sec_trust',
        type: 'trust-bar',
        order: 1,
        visible: true,
        content: {
          items: [
            { text: 'Board-Certified (MT-BC)' },
            { text: 'NCSEAA Approved Provider' },
            { text: 'Bilingual (EN / ES)' },
            { text: 'Serving Gaston & Cleveland County' }
          ]
        }
      },
      {
        id: 'sec_timeline',
        type: 'timeline',
        order: 2,
        visible: true,
        content: {
          label: 'the treble makers timeline',
          title: 'Music grows with you — *from your first note to your favorite chorus.*',
          lede: 'We meet families and individuals at every life stage.',
          stages: [
            { age: '4mo – 2yr', label: 'littlest treble makers', desc: 'Baby music enrichment, parent-child bonding, early developmental support.' },
            { age: '2 – 6',    label: 'little treble makers',    desc: 'Preschool music, summer camps, birthday parties, early developmental therapy.' },
            { age: '7 – 17',   label: 'treble makers',           desc: 'Private lessons, individual therapy for autism, ADHD, sensory needs.' },
            { age: '18 – 40',  label: 'young adults',            desc: 'Developmental disability support, mental health work, adult music lessons.' },
            { age: '40 – 65',  label: 'adults',                  desc: 'Stroke recovery, chronic pain, stress. Facility group sessions.' },
            { age: '65 +',     label: 'seniors',                 desc: 'Memory care, dementia & Alzheimer\'s support at senior facilities.' }
          ]
        }
      },
      {
        id: 'sec_services',
        type: 'services',
        order: 3,
        visible: true,
        content: {
          label: 'what we offer',
          title: 'Three ways we bring *music therapy* to your life.',
          cards: [
            {
              image: '', tag: 'for families', title: 'Individual Music Therapy',
              desc: '1-on-1 clinical sessions with a Board-Certified Music Therapist. Every client begins with an assessment.',
              pricePrefix: 'From', priceAmount: '$60', priceSuffix: '/ session',
              linkText: 'Book intake', linkUrl: 'http://thetreblemakers.as.me'
            },
            {
              image: '', tag: 'for learners', title: 'Private Music Lessons',
              desc: 'Piano, guitar, voice, and more — for kids and adults. Structured, joyful teaching.',
              pricePrefix: 'From', priceAmount: '$35', priceSuffix: '/ 30 min',
              linkText: 'See instruments', linkUrl: '#'
            },
            {
              image: '', tag: 'for the littlest', title: 'Early Childhood Programs',
              desc: 'Preschool, summer camp, and birthday parties built around music enrichment. Bilingual programming available.',
              pricePrefix: 'Programs from', priceAmount: '$25', priceSuffix: '',
              linkText: 'Enroll now', linkUrl: '#'
            }
          ]
        }
      },
      {
        id: 'sec_hudson',
        type: 'feature-block',
        order: 4,
        visible: true,
        content: {
          label: 'the hudson smiles scholarship',
          title: 'No family should have to *choose* between therapy and everything else.',
          body: 'Named for Hudson — a joyful, resilient child who reminded us all what music can do — this scholarship funds reduced-cost therapy for children with developmental, physical, or medical needs.',
          stats: [
            { num: '0–18', lbl: 'age range' },
            { num: '6 mo', lbl: 'weekly sessions per award' },
            { num: 'Aug 1', lbl: 'next application opens' }
          ],
          ctaPrimaryText: 'Apply for a scholarship',
          ctaPrimaryUrl: '#',
          ctaSecondaryText: 'Donate to the fund',
          ctaSecondaryUrl: '#',
          image: ''
        }
      },
      {
        id: 'sec_facilities',
        type: 'rate-list',
        order: 5,
        visible: true,
        content: {
          label: 'for facilities',
          title: 'Bring music therapy *on-site* to your community.',
          intro: 'Contracted music therapy for senior living communities, memory care, group homes, and schools across Gaston and Cleveland County.',
          rates: [
            { name: '1-on-1 sessions', price: '$80 / hour' },
            { name: 'Group therapy (45 min)', price: '$110' },
            { name: 'Location assessment', price: '$80 / hour' },
            { name: 'In-service training (45 min)', price: '$80' },
            { name: 'Travel', price: '$0.65 / mile' }
          ],
          ctaText: 'Request a proposal',
          ctaUrl: 'mailto:thetreblemakersnc@gmail.com',
          image: ''
        }
      },
      {
        id: 'sec_testimonials',
        type: 'testimonial-grid',
        order: 6,
        visible: true,
        content: {
          label: 'what families say',
          title: 'Real families, *real progress.*',
          testimonials: [
            { quote: 'Our son couldn\'t sit still for a 5-minute lesson before Treble Makers. Now he asks about therapy every morning.', name: 'Maria R.', role: 'Parent, Gastonia' },
            { quote: 'Jessica\'s team runs the best group session our facility has ever hosted. Residents with advanced dementia are singing again.', name: 'Denise K.', role: 'Activities Director, Cherryville' },
            { quote: 'The bilingual therapy meant my mother could truly engage — in her own language.', name: 'Julia S.', role: 'Family caregiver' }
          ]
        }
      },
      {
        id: 'sec_cta',
        type: 'cta-strip',
        order: 7,
        visible: true,
        content: {
          label: 'ready when you are',
          title: 'Let\'s find your *first note.*',
          body: 'Start with a free 15-minute call. We\'ll listen, understand your goals, and figure out the right fit.',
          ctaPrimaryText: 'Book a free consult',
          ctaPrimaryUrl: 'http://thetreblemakers.as.me',
          ctaSecondaryText: 'Email Jessica',
          ctaSecondaryUrl: 'mailto:thetreblemakersnc@gmail.com'
        }
      }
    ],
    footer: {
      brandTagline: 'Rooted in music. Growing together.',
      address: '597 Separk Cir\nGastonia, NC 28054\n\n(980) 421-8050\nthetreblemakersnc@gmail.com',
      columns: [
        {
          heading: 'Services',
          links: [
            { text: 'Music Therapy', url: '#services' },
            { text: 'Private Lessons', url: '#services' },
            { text: 'Preschool', url: '#' },
            { text: 'Summer Camp', url: '#' },
            { text: 'Birthday Parties', url: '#' },
            { text: 'Facility Contracts', url: '#facilities' }
          ]
        },
        {
          heading: 'Access & Support',
          links: [
            { text: 'Hudson Smiles Scholarship', url: '#hudson' },
            { text: 'NCSEAA Info', url: '#' },
            { text: 'Funding Resources', url: '#' },
            { text: 'FSA / HSA', url: '#' },
            { text: 'Donate', url: '#' }
          ]
        }
      ],
      newsletterHeading: 'Stay in the loop',
      newsletterText: 'Studio news, workshops, and scholarship announcements — a few times a year.',
      copyrightText: '© 2020–{year} The Treble Makers, LLC — All rights reserved.'
    }
  },
  history: []
};

// Print JSON for manual paste, or if invoked with SITE_URL + ADMIN_PASSWORD env vars, POST directly.

if (process.env.SITE_URL && process.env.ADMIN_PASSWORD) {
  const base = process.env.SITE_URL.replace(/\/$/, '');
  console.log('Logging in…');
  const loginRes = await fetch(`${base}/api/login`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ password: process.env.ADMIN_PASSWORD })
  });
  if (!loginRes.ok) {
    console.error('Login failed:', await loginRes.text());
    process.exit(1);
  }
  const cookie = loginRes.headers.get('set-cookie');
  console.log('Seeding home page…');
  const putRes = await fetch(`${base}/api/content/home`, {
    method: 'PUT',
    headers: { 'content-type': 'application/json', cookie },
    body: JSON.stringify({ current: seed.current })
  });
  if (!putRes.ok) {
    console.error('Seed failed:', await putRes.text());
    process.exit(1);
  }
  console.log('Done. Visit', base, 'to see the site.');
} else {
  console.log(JSON.stringify(seed, null, 2));
  console.log('\n---');
  console.log('To seed automatically: SITE_URL=https://your.netlify.app ADMIN_PASSWORD=xxx node scripts/seed-content.mjs');
}
